'use strict';

const { Plugin, ItemView, Modal, Setting, Notice, Menu, PluginSettingTab, TFile } = require('obsidian');

const VIEW_TYPE = 'cueflow-timeline-view';
const BLOCK_RE = /```cueflow\s*\r?\n([\s\S]*?)\r?\n```/m;
const DEFAULTS = {
  folder: 'CueFlow',
  snapSeconds: 1,
  pixelsPerMinute: 180,
  autoSchedule: true,
  lastProjectPath: '',
  laneDensity: 'standard',
  labelWidth: 182,
};
const LANES = [
  ['导播', '#5B78E5', 'personnel'], ['飞手 A', '#0F9C91', 'personnel'], ['飞手 B', '#D69332', 'personnel'],
  ['无人机', '#7E69CF', 'equipment'], ['地面机器人', '#CF7183', 'equipment'], ['演员/场控', '#637E94', 'personnel'],
];
const DEFAULT_GROUPS = [{ id: 'personnel', name: '执行人员' }, { id: 'equipment', name: '设备' }];
const COLORS = ['#5B78E5', '#0F9C91', '#D69332', '#7E69CF', '#CF7183', '#637E94', '#6E9E53'];
const LABEL_WIDTH = 182;
const HEADER_HEIGHT = 48;
const ROW_HEIGHT = 74;
const GROUP_HEIGHT = 36;
const MIN_CUE_SEC = 1;
const STEPS = [1, 5, 10, 30, 60];
const ZOOMS = [1, 10, 20, 40, 75, 120, 180, 300, 600, 900];

function uid(prefix = 'id') { return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`; }
function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }
function positive(n, fallback) { const value = Number(n); return Number.isFinite(value) && value > 0 ? value : fallback; }
function isInteger(n) { return Number.isInteger(n) && Number.isFinite(n); }
function deepCopy(obj) { return JSON.parse(JSON.stringify(obj)); }
function fmtTime(sec) {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function parseTime(value) {
  const str = String(value ?? '').trim();
  if (!/^\d+(?::[0-5]?\d){0,2}$/.test(str)) return null;
  const parts = str.split(':').map(Number);
  let result = 0;
  for (const part of parts) result = result * 60 + part;
  return isInteger(result) && result >= 0 ? result : null;
}
function roundSnap(s, snap) { return Math.max(0, Math.round(s / snap) * snap); }
function latestCueEnd(project) {
  return project.cues.reduce((end, cue) => Math.max(end, cue.startSec + cue.durationSec), 0);
}
function normalizeFolder(value) {
  const folder = String(value || 'CueFlow').trim().replace(/\\/g, '/').replace(/^\/+|\/+$/g, '') || 'CueFlow';
  const parts = folder.split('/').filter(Boolean);
  if (parts.some(part => part === '.' || part === '..' || /[:*?"<>|]/.test(part))) throw new Error('请填写知识库内的相对目录，例如 CueFlow/发布会');
  return parts.join('/');
}
function filenameFor(name) { return (name.trim().replace(/[\\/:*?"<>|#^\[\]]/g, '-').replace(/\s+/g, ' ').slice(0, 65) || '未命名演示'); }
function xmlEscape(t) { return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function makeExample() {
  const lanes = LANES.map(([name, color, groupId], i) => ({ id: 'lane-' + (i + 1), name, color, groupId }));
  const c = (name, lane, start, duration, details = '', depends = []) => ({ id: uid('cue'), name, laneId: lanes[lane].id, startSec: start, durationSec: duration, note: details, dependsOn: depends, status: 'planned' });
  const opening = c('开场画面 / 主持词', 0, 0, 75, '导播确认投屏和解说词。');
  const mesh = c('端侧 Mesh 组网确认', 1, 0, 95, '2 台遥控、4 架无人机与 1 台地面机器人完成组网。');
  const search = c('四机分区搜索', 1, 105, 180, '确认航线与画面稳定。', [mesh.id]);
  const cam = c('切换搜索画面', 0, 110, 35, '切至飞手 A 遥控画面。', [opening.id]);
  const flex = c('Flex 地面出动', 2, 190, 125, '提示地面机器人操作人员。');
  const actor = c('目标人员入场', 5, 195, 50, '场控通过耳返提示演员。');
  const mark = c('第一幕结束', 0, 330, 0, '里程碑：全部设备进入下一幕准备状态。', [search.id]);
  return { version: 2, name: '无人机空地协同演示（示例）', durationSec: 720, groups: deepCopy(DEFAULT_GROUPS), lanes, cues: [opening, mesh, search, cam, flex, actor, mark] };
}
function validateProject(obj) {
  if (!obj || !Array.isArray(obj.lanes) || !Array.isArray(obj.cues)) throw new Error('文件中缺少 lanes 或 cues 数组');
  if (Number(obj.version) > 2) throw new Error('项目版本较新，请升级 CueFlow 后再打开');
  const laneIds = new Set(), actionIds = new Set();
  for (const lane of obj.lanes) {
    if (!lane || typeof lane.id !== 'string' || !lane.id.trim()) throw new Error('泳道缺少有效 ID');
    if (laneIds.has(lane.id)) throw new Error('泳道 ID 重复，请修复项目文件');
    laneIds.add(lane.id);
  }
  for (const cue of obj.cues) {
    if (!cue || typeof cue.id !== 'string' || !cue.id.trim()) throw new Error('动作缺少有效 ID');
    if (actionIds.has(cue.id)) throw new Error('动作 ID 重复，请修复项目文件');
    actionIds.add(cue.id);
    if (!laneIds.has(cue.laneId)) throw new Error('动作引用了不存在的泳道');
    if (!isInteger(cue.startSec) || !isInteger(cue.durationSec) || cue.startSec < 0 || cue.durationSec < 0 || cue.startSec + cue.durationSec > 86400)
      throw new Error('动作时间必须是非负整数秒，结束时间不能超过 24 小时');
  }
  for (const cue of obj.cues) for (const id of cue.dependsOn || []) {
    if (!actionIds.has(id)) throw new Error('前置动作不存在，请修复项目文件');
    if (id === cue.id) throw new Error('依赖关系会形成循环');
  }
  const legacy = !Array.isArray(obj.groups);
  const groupIds = new Set();
  obj.groups = (legacy ? deepCopy(DEFAULT_GROUPS) : obj.groups)
    .filter(g => g && typeof g.id === 'string' && g.id.trim() && !groupIds.has(g.id) && groupIds.add(g.id))
    .map(g => ({ id: g.id, name: String(g.name || '未命名分组').trim() || '未命名分组' }));
  obj.version = 2;
  obj.name = typeof obj.name === 'string' ? obj.name : '未命名项目';
  obj.durationSec = clamp(Math.ceil(positive(obj.durationSec, 1200)), 60, 86400);
  obj.lanes = obj.lanes.filter(l => l && typeof l.id === 'string').map((l, i) => {
    const fallbackGroup = legacy ? LANES.find(([name]) => name === l.name)?.[2] : '';
    const groupId = typeof l.groupId === 'string' ? l.groupId : fallbackGroup || '';
    return { id: l.id, name: String(l.name || '泳道'), color: /^#[\da-f]{6}$/i.test(l.color) ? l.color : COLORS[i % COLORS.length],
      groupId: groupIds.has(groupId) ? groupId : '' };
  });
  const ids = new Set();
  obj.cues = obj.cues.filter(c => c && typeof c.id === 'string' && typeof c.laneId === 'string' && !ids.has(c.id) && ids.add(c.id))
    .filter(c => obj.lanes.some(l => l.id === c.laneId))
    .map(c => ({
      id: c.id, laneId: c.laneId, name: String(c.name || '未命名动作'),
      startSec: clamp(Math.round(Number(c.startSec) || 0), 0, 86400),
      durationSec: clamp(Math.round(Number(c.durationSec) || 0), 0, 86400),
      note: String(c.note || ''),
      dependsOn: Array.isArray(c.dependsOn) ? c.dependsOn.filter(d => typeof d === 'string' && d !== c.id) : [],
      status: ['planned', 'active', 'done'].includes(c.status) ? c.status : 'planned'
    }));
  const cueIds = new Set(obj.cues.map(c => c.id));
  for (const c of obj.cues) c.dependsOn = Array.from(new Set(c.dependsOn)).filter(id => cueIds.has(id));
  obj.durationSec = Math.max(obj.durationSec, latestCueEnd(obj));
  dependencyOrder(obj);
  return obj;
}
function laneGroupName(project, lane) {
  return project.groups?.find(g => g.id === lane?.groupId)?.name || '未分组';
}
// One row layout drives the timeline, dependency lines, drag targets and SVG export.
function buildLaneLayout(project, collapsed = new Set(), laneHeight = ROW_HEIGHT, groupHeight = GROUP_HEIGHT) {
  const groups = [...(project.groups || [])];
  const groupIds = new Set(groups.map(g => g.id));
  const ungrouped = project.lanes.filter(l => !groupIds.has(l.groupId));
  if (ungrouped.length || !groups.length) groups.push({ id: '', name: '未分组' });
  const rows = [], laneY = new Map();
  let height = 0;
  for (const group of groups) {
    const lanes = group.id ? project.lanes.filter(l => l.groupId === group.id) : ungrouped;
    rows.push({ kind: 'group', group, lanes, y: height, height: groupHeight });
    height += groupHeight;
    if (collapsed.has(group.id)) continue;
    for (const lane of lanes) {
      rows.push({ kind: 'lane', lane, y: height, height: laneHeight });
      laneY.set(lane.id, height); height += laneHeight;
    }
  }
  return { rows, laneY, height };
}
function laneAtY(layout, y) {
  return layout.rows.find(r => r.kind === 'lane' && y >= r.y && y < r.y + r.height);
}
function createsCycle(project, predecessorId, targetId) {
  if (predecessorId === targetId) return true;
  const byId = new Map(project.cues.map(c => [c.id, c]));
  const stack = [predecessorId], seen = new Set();
  while (stack.length) {
    const id = stack.pop();
    if (id === targetId) return true;
    if (seen.has(id)) continue;
    seen.add(id);
    for (const parent of byId.get(id)?.dependsOn || []) stack.push(parent);
  }
  return false;
}
function dependencyOrder(project) {
  const byId = new Map(project.cues.map(c => [c.id, c])), pending = new Map(), children = new Map();
  for (const cue of project.cues) {
    pending.set(cue.id, cue.dependsOn.length);
    for (const id of cue.dependsOn) {
      if (!byId.has(id)) throw new Error('前置动作不存在');
      if (!children.has(id)) children.set(id, []);
      children.get(id).push(cue.id);
    }
  }
  const order = project.cues.filter(c => !pending.get(c.id));
  for (let index = 0; index < order.length; index++) for (const id of children.get(order[index].id) || []) {
    pending.set(id, pending.get(id) - 1);
    if (!pending.get(id)) order.push(byId.get(id));
  }
  if (order.length !== project.cues.length) throw new Error('依赖关系会形成循环');
  return order;
}
function scheduleDependents(project, auto) {
  if (!auto) return;
  const byId = new Map(project.cues.map(c => [c.id, c])), starts = new Map();
  for (const cue of dependencyOrder(project)) {
    let start = cue.startSec;
    for (const id of cue.dependsOn) start = Math.max(start, starts.get(id) + byId.get(id).durationSec);
    if (start + cue.durationSec > 86400) throw new Error('依赖顺延会超过 24 小时，请缩短动作或调整前置时间');
    starts.set(cue.id, start);
  }
  for (const cue of project.cues) cue.startSec = starts.get(cue.id);
}
function hasConflict(project, cue) {
  if (!cue.durationSec) return false;
  return project.cues.some(c => c.id !== cue.id && c.laneId === cue.laneId && c.durationSec && c.startSec < cue.startSec + cue.durationSec && cue.startSec < c.startSec + c.durationSec);
}
function safeMarkdown(obj) {
  return `# ${obj.name}\n\n> CueFlow 项目文件。可以在代码块外编写说明；代码块内是可编辑的调度数据，请保留 cueflow 标记和有效 JSON。\n\n\`\`\`cueflow\n${JSON.stringify(obj, null, 2)}\n\`\`\`\n\n## 导演备注\n\n`;
}
function btn(parent, title, action, cls = '') {
  const el = parent.createEl('button', { text: title, cls: `cueflow-btn ${cls}` });
  el.type = 'button';
  el.addEventListener('click', action);
  return el;
}
function select(parent, choices, current, cb, title = '') {
  const el = parent.createEl('select', { cls: 'cueflow-select', attr: { 'aria-label': title || '选择' } });
  for (const [val, label] of choices) {
    const option = el.createEl('option', { text: String(label) });
    option.value = String(val);
    if (String(val) === String(current)) option.selected = true;
  }
  el.addEventListener('change', () => cb(el.value));
  return el;
}

class StringModal extends Modal {
  constructor(app, title, label, initial, onSave) { super(app); Object.assign(this, { titleText: title, label, initial, onSave }); }
  onOpen() {
    const { contentEl } = this; contentEl.empty(); contentEl.createEl('h3', { text: this.titleText });
    const setting = new Setting(contentEl).setName(this.label).addText(t => t.setValue(this.initial));
    const input = setting.controlEl.querySelector('input');
    const save = () => {
      const value = input.value.trim();
      if (!value) { input.focus(); return new Notice('内容不能为空'); }
      this.close(); this.onSave(value);
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); } });
    new Setting(contentEl).addButton(b => b.setButtonText('确定').setCta().onClick(save)).addButton(b => b.setButtonText('取消').onClick(() => this.close()));
    window.requestAnimationFrame(() => { if (input.isConnected) { input.focus(); input.select(); } });
  }
  onClose() { this.contentEl.empty(); }
}

class LaneModal extends Modal {
  constructor(view, lane = null, groupId = null) {
    super(view.app); this.view = view; this.originalId = lane?.id;
    this.draft = lane ? deepCopy(lane) : { id: uid('lane'), name: '', color: COLORS[view.project.lanes.length % COLORS.length],
      groupId: groupId ?? view.project.groups[0]?.id ?? '' };
    this.project = view.project;
  }
  onOpen() {
    const { contentEl } = this, d = this.draft;
    contentEl.empty(); contentEl.addClass('cueflow-modal');
    contentEl.createEl('h3', { text: this.originalId ? '编辑泳道' : '新建泳道' });
    let input, dropdown;
    new Setting(contentEl).setName('泳道名称').setDesc('填写执行人员或设备名称。')
      .addText(t => { input = t.inputEl; t.setPlaceholder('例如：飞手 A、无人机 1').setValue(d.name); });
    new Setting(contentEl).setName('所属分组').setDesc('可通过时间轴顶部的「+ 分组」创建自定义分组。')
      .addDropdown(dd => {
        dropdown = dd.selectEl;
        for (const group of this.project.groups) dd.addOption(group.id, group.name);
        dd.addOption('', '未分组').setValue(d.groupId);
      });
    const colorSetting = new Setting(contentEl).setName('泳道颜色');
    const color = colorSetting.controlEl.createEl('input', { type: 'color', attr: { 'aria-label': '泳道颜色' } });
    color.value = d.color;
    const save = () => {
      d.name = input.value.trim(); d.groupId = dropdown.value; d.color = color.value;
      if (!d.name) { input.focus(); return new Notice('请填写泳道名称'); }
      if (this.view.project !== this.project) return new Notice('项目已切换，请在当前项目重新创建泳道');
      this.view.saveLane(d); this.close();
    };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); }
    });
    new Setting(contentEl).addButton(b => b.setButtonText(this.originalId ? '保存泳道' : '创建泳道').setCta().onClick(save))
      .addButton(b => b.setButtonText('取消').onClick(() => this.close()));
    window.requestAnimationFrame(() => { if (input.isConnected) { input.focus(); if (this.originalId) input.select(); } });
  }
  onClose() { this.contentEl.empty(); }
}

class CueModal extends Modal {
  constructor(view, original) { super(view.app); this.view = view; this.original = original; this.draft = deepCopy(original); }
  onOpen() {
    const { contentEl } = this, view = this.view, d = this.draft, project = view.project;
    contentEl.empty(); contentEl.addClass('cueflow-modal'); contentEl.createEl('h3', { text: view.project.cues.some(c => c.id === d.id) ? '编辑调度动作' : '添加调度动作' });
    const fields = {}, dependencies = new Map();
    new Setting(contentEl).setName('动作名称').addText(t => { fields.name = t.inputEl; t.setPlaceholder('如：四机区域搜索').setValue(d.name); });
    new Setting(contentEl).setName('执行角色 / 设备').addDropdown(dd => {
      fields.lane = dd.selectEl;
      for (const row of buildLaneLayout(project).rows) if (row.kind === 'lane') dd.addOption(row.lane.id, laneGroupName(project, row.lane) + ' / ' + row.lane.name);
      dd.setValue(d.laneId);
    });
    new Setting(contentEl).setName('开始时间（T+分:秒）').setDesc('例如 03:15 或 00:03:15')
      .addText(t => { fields.start = t.inputEl; t.setValue(fmtTime(d.startSec)); });
    new Setting(contentEl).setName('持续时间（分:秒）').setDesc('00:00 表示里程碑')
      .addText(t => { fields.duration = t.inputEl; t.setValue(fmtTime(d.durationSec)); });
    new Setting(contentEl).setName('执行状态').addDropdown(dd => { fields.status = dd.selectEl;
      dd.addOption('planned', '待执行').addOption('active', '进行中').addOption('done', '已完成').setValue(d.status); });
    new Setting(contentEl).setName('操作备注').addTextArea(t => { fields.note = t.inputEl;
      t.setPlaceholder('动作、口令、设备、注意事项等').setValue(d.note); t.inputEl.rows = 4; });
    contentEl.createEl('h4', { text: '前置动作（可多选，结束后才允许本任务开始）' });
    const container = contentEl.createDiv({ cls: 'cueflow-dependencies' });
    const candidates = project.cues.filter(c => c.id !== d.id);
    if (!candidates.length) container.createDiv({ text: '尚无其他动作，可保存后再添加依赖。', cls: 'cueflow-muted' });
    for (const other of candidates) {
      const item = container.createEl('label', { cls: 'cueflow-checkbox' });
      const checkbox = item.createEl('input', { type: 'checkbox' });
      checkbox.checked = d.dependsOn.includes(other.id);
      dependencies.set(other.id, checkbox);
      item.createSpan({ text: `${other.name} · T+${fmtTime(other.startSec)}` });
    }
    const save = () => {
      if (view.project !== project) return new Notice('项目已切换，请重新打开动作编辑');
      d.name = fields.name.value.trim(); d.laneId = fields.lane.value; d.status = fields.status.value; d.note = fields.note.value;
      d.dependsOn = [...dependencies].filter(([, input]) => input.checked).map(([id]) => id);
      const start = parseTime(fields.start.value), duration = parseTime(fields.duration.value);
      if (!d.name) return new Notice('动作名称不能为空');
      if (start === null || duration === null) return new Notice('时间格式错误：请填写 03:15 这样的分:秒格式');
      if (start + duration > 86400) return new Notice('单场演示最多支持 24 小时');
      d.startSec = start; d.durationSec = duration;
      for (const prevId of d.dependsOn) {
        if (createsCycle(project, prevId, d.id)) return new Notice('依赖关系会形成循环，请调整选择');
      }
      if (view.saveCue(d)) this.close();
    };
    new Setting(contentEl).addButton(b => b.setButtonText('保存动作').setCta().onClick(save))
      .addButton(b => b.setButtonText('取消').onClick(() => this.close()));
  }
  onClose() { this.contentEl.empty(); }
}

class ProjectDurationModal extends Modal {
  constructor(view, editProject = false) { super(view.app); this.view = view; this.project = view.project; this.editProject = editProject; }
  onOpen() {
    const { contentEl } = this, view = this.view;
    contentEl.empty(); contentEl.createEl('h3', { text: this.editProject ? '项目设置' : '时间轴总时长' });
    let input, nameInput;
    if (this.editProject) new Setting(contentEl).setName('项目名称')
      .addText(t => { nameInput = t.inputEl; t.setValue(this.project.name); });
    new Setting(contentEl).setName('总时长').setDesc('分:秒或时:分:秒，例如 30:00、01:30:00；精确到秒。')
      .addText(t => { input = t.inputEl; t.setValue(fmtTime(view.calculateDuration())).setPlaceholder('例如 30:00'); });
    contentEl.createDiv({ cls: 'cueflow-muted',
      text: '最后一个动作结束于 T+' + fmtTime(latestCueEnd(this.project)) + '。缩短时间轴时会保留全部动作。' });
    new Setting(contentEl).setName('快捷增加').addButton(b => b.setButtonText('+1 分钟').onClick(() => add(60)))
      .addButton(b => b.setButtonText('+5 分钟').onClick(() => add(300)))
      .addButton(b => b.setButtonText('+10 分钟').onClick(() => add(600)));
    const add = seconds => {
      const current = parseTime(input.value);
      if (current === null) return new Notice('请填写有效时长，例如 30:00 或 01:30:00');
      if (current + seconds > 86400) return new Notice('单场演示最多支持 24 小时');
      input.value = fmtTime(current + seconds);
    };
    const save = () => {
      if (view.project !== this.project) return new Notice('项目已切换，请重新打开总时长设置');
      const seconds = parseTime(input.value);
      if (seconds === null) { input.focus(); return new Notice('请填写有效时长，例如 30:00 或 01:30:00'); }
      const saved = this.editProject ? view.updateProjectSettings({ name: nameInput.value, durationSec: seconds }) : view.setProjectDuration(seconds);
      if (saved) this.close();
    };
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); save(); }
    });
    new Setting(contentEl).addButton(b => b.setButtonText(this.editProject ? '保存项目设置' : '保存总时长').setCta().onClick(save))
      .addButton(b => b.setButtonText('取消').onClick(() => this.close()));
    window.setTimeout(() => { if (input.isConnected) { input.focus(); input.select(); } }, 0);
  }
  onClose() { this.contentEl.empty(); }
}

class DisplaySettingsModal extends Modal {
  constructor(view) { super(view.app); this.view = view; }
  onOpen() {
    const { contentEl } = this, view = this.view;
    contentEl.empty(); contentEl.createEl('h3', { text: '显示设置' });
    new Setting(contentEl).setName('时间轴总时长').setDesc('设置本项目的时间范围，后续动作超出时自动延长。')
      .addButton(b => b.setButtonText(fmtTime(view.calculateDuration())).onClick(() => { this.close(); view.openDurationSettings(); }));
    new Setting(contentEl).setName('时间轴缩放').setDesc('向右放大，便于逐秒调整；向左缩小，查看完整排程。')
      .addSlider(s => s.setLimits(1, 900, 1).setValue(view.scale * 60).setDynamicTooltip().onChange(v => view.setPixelsPerMinute(v)));
    new Setting(contentEl).setName('快速缩放')
      .addButton(b => b.setButtonText('适应窗口').onClick(() => { view.fitTimeline(); this.close(); }))
      .addButton(b => b.setButtonText('恢复默认').onClick(() => { view.setPixelsPerMinute(180); this.close(); }));
    new Setting(contentEl).setName('人员 / 设备列宽').setDesc('也可拖动左栏右侧的分隔线；双击分隔线恢复默认。')
      .addSlider(s => s.setLimits(160, 600, 1).setValue(view.labelWidth).setDynamicTooltip().onChange(v => view.setLabelWidth(v)));
    new Setting(contentEl).setName('人员 / 设备显示').setDesc('紧凑显示会缩小泳道高度，让更多人员和设备同时显示。')
      .addDropdown(d => d.addOption('standard', '标准显示').addOption('compact', '紧凑显示').setValue(view.density || 'standard').onChange(v => view.setDensity(v)));
    new Setting(contentEl).addButton(b => b.setButtonText('完成').setCta().onClick(() => this.close()));
  }
  onClose() { this.contentEl.empty(); }
}

class CueFlowSettingTab extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    const { containerEl } = this; containerEl.empty(); containerEl.createEl('h2', { text: 'CueFlow Timeline 设置' });
    new Setting(containerEl).setName('项目保存目录').setDesc('Vault 内的 Markdown 文件夹，修改后新项目存到新目录；原有文件不会移动。')
      .addText(t => t.setValue(this.plugin.settings.folder).onChange(async v => {
        try { this.plugin.settings.folder = normalizeFolder(v); await this.plugin.saveSettings(); }
        catch (err) { new Notice(err.message); }
      }));
    new Setting(containerEl).setName('默认时间吸附').addDropdown(d => {
      for (const s of STEPS) d.addOption(String(s), `${s} 秒`);
      d.setValue(String(this.plugin.settings.snapSeconds)).onChange(async v => {
        this.plugin.settings.snapSeconds = Number(v);
        for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) { leaf.view.snap = Number(v); if (leaf.view.project) leaf.view.render(true); }
        await this.plugin.saveSettings();
      });
    });
    new Setting(containerEl).setName('默认缩放比例').setDesc('每分钟占用的横向像素。')
      .addSlider(s => s.setLimits(1, 900, 1).setValue(this.plugin.settings.pixelsPerMinute).setDynamicTooltip()
        .onChange(async v => {
          this.plugin.settings.pixelsPerMinute = v;
          for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) leaf.view.setPixelsPerMinute(v, false);
          await this.plugin.saveSettings();
        }));
    new Setting(containerEl).setName('人员 / 设备默认显示').setDesc('立即应用到当前时间轴，并用于下次打开。')
      .addDropdown(d => d.addOption('standard', '标准显示').addOption('compact', '紧凑显示').setValue(this.plugin.settings.laneDensity)
        .onChange(async v => {
          this.plugin.settings.laneDensity = v;
          for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) leaf.view.setDensity(v, false);
          await this.plugin.saveSettings();
        }));
    new Setting(containerEl).setName('人员 / 设备列宽').setDesc('左栏宽度，单位像素。也可直接拖动时间轴左栏的右边界。')
      .addSlider(s => s.setLimits(160, 600, 1).setValue(this.plugin.settings.labelWidth).setDynamicTooltip()
        .onChange(async value => {
          this.plugin.settings.labelWidth = value;
          for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) leaf.view.setLabelWidth(value, false);
          await this.plugin.saveSettings();
        }));
    new Setting(containerEl).setName('启用依赖自动顺延').setDesc('仅当后置动作与前置动作发生时间冲突时，向后顺延。')
      .addToggle(t => t.setValue(this.plugin.settings.autoSchedule).onChange(async v => {
        this.plugin.settings.autoSchedule = v;
        for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) { leaf.view.autoSchedule = v; if (leaf.view.project) leaf.view.render(true); }
        await this.plugin.saveSettings();
      }));
  }
}

class CueFlowView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf); this.plugin = plugin; this.project = null; this.file = null;
    this.scale = plugin.settings.pixelsPerMinute / 60;
    this.snap = plugin.settings.snapSeconds;
    this.autoSchedule = plugin.settings.autoSchedule;
    this.density = plugin.settings.laneDensity || 'standard';
    this.railWidth = clamp(positive(plugin.settings.labelWidth, LABEL_WIDTH), 160, 600);
    this.history = []; this.historyIndex = -1;
    this.selectedId = null; this.pendingLinkId = null;
    this.elapsed = 0; this.running = false; this.tickHandle = null;
    this.timerOrigin = 0; this.timerBase = 0;
    this.saveChain = Promise.resolve(); this.saveTimer = null;
    this.collapsedGroups = new Set();
    this.savedBlocks = new Map(); this.dirty = false; this.saveError = ''; this.editRevision = 0;
  }
  get labelWidth() { return clamp(positive(this.railWidth ?? this.plugin?.settings?.labelWidth, LABEL_WIDTH), 160, 600); }
  getViewType() { return VIEW_TYPE; }
  getDisplayText() { return this.project ? `CueFlow · ${this.project.name}` : 'CueFlow 时间轴'; }
  getIcon() { return 'calendar-clock'; }
  async onOpen() {
    this.contentEl.addClass('cueflow-root');
    await this.refreshFiles();
    const saved = this.files.find(f => f.path === this.plugin.settings.lastProjectPath);
    if (saved) await this.openFile(saved);
    else if (this.files.length) await this.openFile(this.files[0]);
    else await this.createProject('无人机空地协同演示（示例）', true);
  }
  async onClose() {
    this.inlineEdit?.finish(true, true);
    this.pauseClock(); this.pointerCleanup?.();
    const pending = this.dirty || !!this.saveTimer;
    if (this.saveTimer) { window.clearTimeout(this.saveTimer); this.saveTimer = null; }
    if (pending) await this.saveNow();
    await this.saveChain;
    if (this.dirty) await this.saveRecoveryCopy(false);
  }
  async refreshFiles() {
    const folder = this.plugin.settings.folder;
    this.files = this.app.vault.getFiles().filter(f => f.path.startsWith(`${folder}/`) && f.extension === 'md').sort((a,b) => a.basename.localeCompare(b.basename, 'zh-CN'));
  }
  async ensureFolder() {
    this.plugin.settings.folder = normalizeFolder(this.plugin.settings.folder);
    const segments = this.plugin.settings.folder.split('/').filter(Boolean); let path = '';
    for (const seg of segments) { path = path ? `${path}/${seg}` : seg; if (!this.app.vault.getAbstractFileByPath(path)) await this.app.vault.createFolder(path); }
  }
  async createProject(name, example = false) {
    try {
      if (this.dirty && !(await this.saveNow())) return;
      await this.ensureFolder();
      const folder = this.plugin.settings.folder;
      const base = filenameFor(name);
      let path = `${folder}/${base}.md`, i = 2;
      while (this.app.vault.getAbstractFileByPath(path)) path = `${folder}/${base}-${i++}.md`;
      const proj = example ? makeExample() : { version: 2, name, durationSec: 1200, groups: deepCopy(DEFAULT_GROUPS),
        lanes: LANES.map(([n, color, groupId]) => ({ id: uid('lane'), name: n, color, groupId })), cues: [] };
      proj.name = name;
      const file = await this.app.vault.create(path, safeMarkdown(proj));
      await this.refreshFiles();
      await this.openFile(file);
    } catch (err) { new Notice(`创建项目失败：${err.message}`); }
  }
  async openFile(file, discardUnsaved = false) {
    try {
      this.inlineEdit?.finish(true, true);
      if (this.saveTimer) { clearTimeout(this.saveTimer); this.saveTimer = null; }
      if (this.dirty && !discardUnsaved && !(await this.saveNow())) return false;
      await this.saveChain;
      if (this.dirty && !discardUnsaved) return false;
      const raw = await this.app.vault.read(file), match = raw.match(BLOCK_RE);
      if (!match) throw new Error('没有找到 ```cueflow 数据块');
      const project = validateProject(JSON.parse(match[1]));
      this.file = file; this.project = project; this.selectedId = null; this.pendingLinkId = null;
      this.savedBlocks.set(file.path, match[0]); this.dirty = false; this.saveError = '';
      this.collapsedGroups = new Set();
      this.pauseClock(); this.elapsed = 0; this.history = [JSON.stringify(this.project)]; this.historyIndex = 0;
      this.plugin.settings.lastProjectPath = file.path;
      await this.plugin.saveSettings();
      this.render(); return true;
    } catch (err) { new Notice(`无法打开项目：${err.message}`); return false; }
  }
  recordChange(render = true) {
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(JSON.stringify(this.project));
    if (this.history.length > 60) this.history.shift();
    this.historyIndex = this.history.length - 1;
    this.queueSave(); if (render) this.render(true);
  }
  undo() {
    if (this.historyIndex <= 0) return;
    this.historyIndex--; this.project = JSON.parse(this.history[this.historyIndex]); this.queueSave(); this.render(true);
  }
  redo() {
    if (this.historyIndex >= this.history.length - 1) return;
    this.historyIndex++; this.project = JSON.parse(this.history[this.historyIndex]); this.queueSave(); this.render(true);
  }
  queueSave() {
    this.dirty = true; this.editRevision++; this.updateSaveStatus();
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => { this.saveTimer = null; this.saveNow(); }, 280);
  }
  updateSaveStatus() {
    if (this.saveStatusEl) {
      this.saveStatusEl.setText(this.saveError ? '未保存：' + this.saveError : this.dirty ? '待保存…' : '已保存');
      this.saveStatusEl.classList.toggle('cueflow-save-error', !!this.saveError);
    }
    if (this.recoveryActions) this.recoveryActions.hidden = !this.saveError;
  }
  async saveNow() {
    if (!this.file || !this.project) return true;
    const file = this.file, snapshot = deepCopy(this.project), revision = this.editRevision;
    this.saveChain = this.saveChain.catch(() => {}).then(async () => {
      const current = await this.app.vault.read(file), match = current.match(BLOCK_RE);
      if (!match) throw new Error('文件中的 CueFlow 数据块已移除，请保存为副本或重新读取');
      if ((current.match(new RegExp(BLOCK_RE.source, 'gm')) || []).length !== 1) throw new Error('文件中必须只有一个 CueFlow 数据块');
      const expected = this.savedBlocks?.get(file.path);
      if (expected !== undefined && match[0] !== expected) throw new Error('排程已被外部修改，请保存为副本或重新读取');
      const block = '```cueflow\n' + JSON.stringify(snapshot, null, 2) + '\n```';
      const result = current.replace(BLOCK_RE, () => block);
      if (current !== result) await this.app.vault.modify(file, result);
      if (!this.savedBlocks) this.savedBlocks = new Map();
      this.savedBlocks.set(file.path, block);
      if (this.file?.path === file.path && this.editRevision === revision) { this.dirty = false; this.saveError = ''; this.updateSaveStatus(); }
      return true;
    }).catch(err => {
      this.dirty = true; this.saveError = err.message; this.updateSaveStatus();
      new Notice('CueFlow 保存失败：' + err.message); return false;
    });
    return this.saveChain;
  }
  async saveRecoveryCopy(open = true) {
    try {
      const project = deepCopy(this.project), parent = this.file.path.slice(0, this.file.path.lastIndexOf('/'));
      project.name += '（恢复副本）';
      const base = parent + '/' + filenameFor(project.name);
      let path = base + '.md', index = 2;
      while (this.app.vault.getAbstractFileByPath(path)) path = base + '-' + index++ + '.md';
      const file = await this.app.vault.create(path, safeMarkdown(project));
      new Notice('当前修改已保存为 ' + path);
      if (open) { await this.refreshFiles(); await this.openFile(file, true); }
      return file;
    } catch (err) { new Notice('恢复副本保存失败：' + err.message, 12000); return null; }
  }
  saveCue(cue) {
    try {
      const draft = deepCopy(cue); draft.name = draft.name.trim();
      if (!draft.name) throw new Error('动作名称不能为空');
      const candidate = deepCopy(this.project), index = candidate.cues.findIndex(c => c.id === draft.id);
      if (index < 0) candidate.cues.push(draft); else candidate.cues[index] = draft;
      validateProject(candidate); scheduleDependents(candidate, this.autoSchedule);
      candidate.durationSec = Math.max(candidate.durationSec, latestCueEnd(candidate));
      const existing = new Map(this.project.cues.map(c => [c.id, c]));
      this.project.cues = candidate.cues.map(c => existing.has(c.id) ? Object.assign(existing.get(c.id), c) : c);
      this.project.durationSec = candidate.durationSec;
      this.selectedId = draft.id; this.recordChange(); return true;
    } catch (err) { new Notice(err.message); return false; }
  }
  deleteCue(id, confirm = true) {
    const cue = this.project.cues.find(c => c.id === id); if (!cue) return;
    if (confirm && !window.confirm(`删除动作「${cue.name}」？`)) return;
    this.pointerCleanup?.();
    if (this.inlineEdit?.id === id) this.inlineEdit.finish(false);
    if (this.pendingLinkId === id) this.pendingLinkId = null;
    this.project.cues = this.project.cues.filter(c => c.id !== id);
    for (const c of this.project.cues) c.dependsOn = c.dependsOn.filter(d => d !== id);
    this.selectedId = null; this.recordChange();
  }
  addCue(laneId, startSec = 0, durationSec = 60) {
    const cue = { id: uid('cue'), name: '新动作', laneId, startSec: Math.round(startSec), durationSec: Math.round(durationSec), note: '', dependsOn: [], status: 'planned' };
    new CueModal(this, cue).open();
  }
  createCueAt(laneId, seconds) {
    if (!this.project.lanes.some(lane => lane.id === laneId) || !Number.isFinite(seconds)) return null;
    const startSec = clamp(roundSnap(seconds, this.snap), 0, 86399);
    const cue = { id: uid('cue'), name: '新动作', laneId, startSec, durationSec: Math.min(60, 86400 - startSec), note: '', dependsOn: [], status: 'planned' };
    const pending = this.pendingLinkId; this.pendingLinkId = null;
    if (!this.saveCue(cue)) { this.pendingLinkId = pending; return null; }
    this.beginInlineCueName(cue.id);
    return this.project.cues.find(item => item.id === cue.id);
  }
  renameCueName(id, value, project = this.project) {
    const name = String(value ?? '').trim(), cue = this.project.cues.find(item => item.id === id);
    if (this.project !== project || !cue || !name) return false;
    if (cue.name !== name) { cue.name = name; this.recordChange(false); }
    return true;
  }
  beginInlineCueName(id) {
    this.inlineEdit?.finish(true, true);
    const project = this.project, cue = project.cues.find(item => item.id === id);
    const el = [...this.board.querySelectorAll('.cueflow-cue')].find(node => node.dataset.id === id);
    if (!cue || !el) return;
    const title = el.querySelector('.cueflow-cue-title'); title.empty(); el.classList.add('cueflow-editing');
    const input = title.createEl('input', { type: 'text', cls: 'cueflow-inline-editor', attr: { 'aria-label': '任务名称', placeholder: '输入任务名称' } });
    input.value = cue.name;
    let finished = false;
    const finish = (commit = true, fromBlur = false) => {
      if (finished) return true;
      if (commit && !input.value.trim() && !fromBlur) { new Notice('动作名称不能为空'); input.focus(); return false; }
      finished = true; this.inlineEdit = null; input.removeEventListener('blur', blur);
      if (commit && input.value.trim()) this.renameCueName(id, input.value, project);
      el.classList.remove('cueflow-editing'); title.setText(cue.durationSec === 0 ? '◆ ' + cue.name : cue.name);
      el.setAttribute('title', cue.name + '\nT+' + fmtTime(cue.startSec) + ' 至 T+' + fmtTime(cue.startSec + cue.durationSec) + '\n' + cue.note);
      if (fromBlur) window.setTimeout(() => { if (this.project === project && this.footerEl?.isConnected && !this.inlineEdit) this.renderFooter(); }, 0);
      else if (this.project === project) this.renderFooter();
      if (!fromBlur && this.scroller.isConnected) this.scroller.focus({ preventScroll: true });
      return true;
    };
    const blur = () => finish(true, true);
    this.inlineEdit = { id, input, finish };
    for (const type of ['pointerdown', 'click', 'dblclick']) input.addEventListener(type, e => e.stopPropagation());
    input.addEventListener('keydown', e => {
      e.stopPropagation();
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Enter') { e.preventDefault(); finish(); }
      if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', blur);
    input.focus({ preventScroll: true }); input.select();
  }
  handleCanvasKeydown(e) {
    if (e.defaultPrevented || e.isComposing || e.keyCode === 229 || e.target?.closest?.('input,textarea,select,button,[role="button"],[role="separator"],[contenteditable]:not([contenteditable="false"])')) return;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); return; }
    if (e.key === 'Escape' && this.pendingLinkId) { e.preventDefault(); this.pendingLinkId = null; this.render(true); return; }
    if (!mod && !e.altKey && e.key === 'Delete' && this.selectedId) { e.preventDefault(); this.deleteCue(this.selectedId, false); }
  }
  duplicateCue(cue) {
    const copy = deepCopy(cue); copy.id = uid('cue'); copy.name += '（副本）'; copy.startSec = cue.startSec + Math.max(cue.durationSec, this.snap); copy.dependsOn = [];
    this.saveCue(copy);
  }
  addDependency(predecessorId, dependentId) {
    if (createsCycle(this.project, predecessorId, dependentId)) return new Notice('不能添加循环依赖');
    const target = this.project.cues.find(c => c.id === dependentId);
    if (!target || target.dependsOn.includes(predecessorId)) return new Notice('依赖关系已存在');
    const draft = deepCopy(target); draft.dependsOn.push(predecessorId);
    this.pendingLinkId = null;
    if (!this.saveCue(draft)) { this.pendingLinkId = predecessorId; this.render(true); }
  }
  renameLane(lane) { new LaneModal(this, lane).open(); }
  addLane(groupId = null) { new LaneModal(this, null, groupId).open(); }
  saveLane(lane) {
    const draft = deepCopy(lane); draft.name = draft.name.trim();
    if (!draft.name) return new Notice('请填写泳道名称');
    if (!this.project.groups.some(g => g.id === draft.groupId)) draft.groupId = '';
    const index = this.project.lanes.findIndex(l => l.id === draft.id);
    if (index < 0) this.project.lanes.push(draft); else this.project.lanes[index] = draft;
    this.collapsedGroups.delete(draft.groupId); this.recordChange();
  }
  addGroup() {
    new StringModal(this.app, '新建分组', '分组名称', '', name => {
      this.project.groups.push({ id: uid('group'), name }); this.recordChange();
    }).open();
  }
  renameGroup(group) {
    new StringModal(this.app, '修改分组名称', '分组名称', group.name, name => { group.name = name; this.recordChange(); }).open();
  }
  moveGroup(id, delta) {
    const groups = this.project.groups, index = groups.findIndex(g => g.id === id), target = index + delta;
    if (index < 0 || target < 0 || target >= groups.length) return;
    [groups[index], groups[target]] = [groups[target], groups[index]]; this.recordChange();
  }
  moveGroupTo(id, anchorId, placement = 'before') {
    const groups = this.project.groups, group = groups.find(item => item.id === id);
    if (!group || id === anchorId) return false;
    const rest = groups.filter(item => item.id !== id), anchorIndex = rest.findIndex(item => item.id === anchorId);
    if (anchorIndex < 0) return false;
    const index = anchorIndex + (placement === 'after' ? 1 : 0);
    const next = [...rest.slice(0, index), group, ...rest.slice(index)];
    if (next.every((item, i) => item === groups[i])) return false;
    // Reorder only group IDs. Lane IDs, action times and dependency edges stay intact.
    this.project.groups = next; this.recordChange(); return true;
  }
  beginGroupDrag(event, group) {
    if (event.button !== 0 || !group.id) return;
    event.preventDefault(); event.stopPropagation(); this.pointerCleanup?.();
    this.scroller.focus({ preventScroll: true });
    const project = this.project, startX = event.clientX, startY = event.clientY;
    const headers = this.laneLayout.rows.filter(row => row.kind === 'group');
    const sections = headers.map((row, index) => ({ ...row, end: headers[index + 1]?.y ?? this.laneLayout.height }));
    const source = sections.find(row => row.group.id === group.id);
    const laneIds = new Set(source.lanes.map(lane => lane.id));
    const sourceNodes = [...this.rowsEl.children].filter(el =>
      el.classList.contains('cueflow-group-row') ? el.dataset.groupId === group.id :
      el.classList.contains('cueflow-lane-row') && laneIds.has(el.dataset.laneId));
    let active = false, destination = null, preview = null;
    const indicator = this.rowsEl.createDiv({ cls: 'cueflow-group-drop-line' }); indicator.hidden = true;
    const move = e => {
      if (!active && Math.hypot(e.clientX - startX, e.clientY - startY) < 4) return;
      if (!active) {
        active = true; sourceNodes.forEach(el => el.classList.add('cueflow-group-reordering'));
        preview = document.body.createDiv({ cls: 'cueflow-group-drag-preview', attr: { 'aria-hidden': 'true' } });
        preview.classList.toggle('cueflow-compact', this.density === 'compact');
        const cues = project.cues.filter(cue => laneIds.has(cue.laneId)).length;
        preview.createDiv({ cls: 'cueflow-group-drag-summary', text: group.name + ' · ' + source.lanes.length + ' 条泳道 · ' + cues + ' 个动作' });
        const fullWidth = parseFloat(this.board.style.width), height = source.end - source.y;
        const scale = Math.min(1, 680 / fullWidth, 260 / height);
        const frame = preview.createDiv({ cls: 'cueflow-group-drag-frame' });
        frame.style.width = (fullWidth * scale) + 'px'; frame.style.height = (height * scale) + 'px';
        const content = frame.createDiv({ cls: 'cueflow-group-drag-content' });
        content.style.cssText = 'width:' + fullWidth + 'px;height:' + height + 'px;transform:scale(' + scale + ');transform-origin:top left';
        sourceNodes.forEach(el => { const clone = el.cloneNode(true); clone.classList.remove('cueflow-group-reordering'); content.appendChild(clone); });
        const links = this.rowsEl.querySelector('.cueflow-links').cloneNode(true);
        links.style.top = -source.y + 'px';
        const marker = links.querySelector('marker'), markerId = uid('group-preview-arrow');
        if (marker) marker.id = markerId;
        links.querySelectorAll('[marker-end]').forEach(path => path.setAttribute('marker-end', 'url(#' + markerId + ')'));
        content.appendChild(links);
      }
      preview.style.left = Math.max(8, Math.min(e.clientX + 12, window.innerWidth - preview.offsetWidth - 8)) + 'px';
      preview.style.top = Math.max(8, Math.min(e.clientY + 12, window.innerHeight - preview.offsetHeight - 8)) + 'px';
      const bounds = this.scroller.getBoundingClientRect();
      if (e.clientY < bounds.top + HEADER_HEIGHT + 18) this.scroller.scrollTop -= 16;
      else if (e.clientY > bounds.bottom - 24) this.scroller.scrollTop += 16;
      const y = e.clientY - this.rowsEl.getBoundingClientRect().top;
      const target = sections.find(row => y >= row.y && y < row.end);
      destination = null; indicator.hidden = true;
      if (!target?.group.id || target.group.id === group.id) return;
      const placement = y < (target.y + target.end) / 2 ? 'before' : 'after';
      destination = { id: target.group.id, placement };
      indicator.style.top = (placement === 'before' ? target.y : target.end) + 'px'; indicator.hidden = false;
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', cancel); window.removeEventListener('keydown', key);
      sourceNodes.forEach(el => el.classList.remove('cueflow-group-reordering')); preview?.remove(); indicator.remove();
      this.pointerCleanup = null;
    };
    const cancel = () => cleanup();
    const key = e => { if (e.key === 'Escape') { e.preventDefault(); cancel(); } };
    const end = () => {
      const target = destination; cleanup();
      if (active && target && this.project === project) this.moveGroupTo(group.id, target.id, target.placement);
    };
    this.pointerCleanup = cancel;
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', cancel); window.addEventListener('keydown', key);
  }
  removeGroup(group) {
    if (!window.confirm('删除分组「' + group.name + '」？其中的泳道和动作会保留，泳道移至「未分组」。')) return;
    this.project.groups = this.project.groups.filter(g => g.id !== group.id);
    for (const lane of this.project.lanes) if (lane.groupId === group.id) lane.groupId = '';
    this.collapsedGroups.delete(''); this.collapsedGroups.delete(group.id); this.recordChange();
  }
  toggleGroup(id) {
    if (this.collapsedGroups.has(id)) this.collapsedGroups.delete(id); else this.collapsedGroups.add(id);
    this.render(true);
  }
  removeLane(lane) {
    if (this.project.lanes.length === 1) return new Notice('至少保留一条泳道');
    if (this.project.cues.some(c => c.laneId === lane.id)) return new Notice('该泳道有动作，请先移动或删除这些动作');
    if (!window.confirm(`删除泳道「${lane.name}」？`)) return;
    this.project.lanes = this.project.lanes.filter(l => l.id !== lane.id); this.recordChange();
  }
  moveLane(id, delta) {
    const arr = this.project.lanes, idx = arr.findIndex(l => l.id === id);
    if (idx < 0) return;
    const peers = arr.filter(l => l.groupId === arr[idx].groupId), peerIndex = peers.findIndex(l => l.id === id), target = peers[peerIndex + delta];
    if (!target) return;
    const dest = arr.indexOf(target);
    [arr[idx], arr[dest]] = [arr[dest], arr[idx]]; this.recordChange();
  }
  moveLaneTo(id, groupId, anchorId = null, placement = 'after') {
    const lanes = this.project.lanes, lane = lanes.find(item => item.id === id);
    if (!lane || anchorId === id) return false;
    if (groupId && !this.project.groups.some(group => group.id === groupId)) return false;
    const rest = lanes.filter(item => item.id !== id);
    let index;
    if (anchorId !== null) {
      const anchorIndex = rest.findIndex(item => item.id === anchorId && item.groupId === groupId);
      if (anchorIndex < 0) return false;
      index = anchorIndex + (placement === 'before' ? 0 : 1);
    } else {
      index = rest.reduce((last, item, i) => item.groupId === groupId ? i + 1 : last, -1);
      if (index < 0) index = rest.length;
    }
    const next = [...rest.slice(0, index), lane, ...rest.slice(index)];
    if (lane.groupId === groupId && next.every((item, i) => item === lanes[i])) return false;
    lane.groupId = groupId; this.project.lanes = next;
    this.collapsedGroups.delete(groupId); this.recordChange(); return true;
  }
  beginLaneDrag(event, lane) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation(); this.pointerCleanup?.();
    this.scroller.focus({ preventScroll: true });
    const project = this.project, startX = event.clientX, startY = event.clientY;
    let active = false, destination = null, ghost = null;
    const row = [...this.rowsEl.querySelectorAll('.cueflow-lane-row')].find(el => el.dataset.laneId === lane.id);
    const indicator = this.rowsEl.createDiv({ cls: 'cueflow-lane-drop-line' }); indicator.hidden = true;
    const clearGroupHighlight = () => this.rowsEl.querySelectorAll('.cueflow-group-drop-target').forEach(el => el.classList.remove('cueflow-group-drop-target'));
    const preview = e => {
      if (!active && Math.hypot(e.clientX - startX, e.clientY - startY) < 4) return;
      if (!active) {
        active = true; row?.classList.add('cueflow-lane-reordering');
        ghost = document.body.createDiv({ cls: 'cueflow-lane-drag-preview', text: lane.name });
        ghost.style.width = (this.labelWidth - 12) + 'px';
      }
      ghost.style.left = (e.clientX + 12) + 'px'; ghost.style.top = (e.clientY + 10) + 'px';
      const bounds = this.scroller.getBoundingClientRect();
      if (e.clientY < bounds.top + HEADER_HEIGHT + 18) this.scroller.scrollTop -= 16;
      else if (e.clientY > bounds.bottom - 24) this.scroller.scrollTop += 16;
      const y = e.clientY - this.rowsEl.getBoundingClientRect().top;
      const target = this.laneLayout.rows.find(item => y >= item.y && y < item.y + item.height);
      clearGroupHighlight(); indicator.hidden = true; destination = null;
      if (!target) return;
      if (target.kind === 'group') {
        destination = { groupId: target.group.id, anchorId: null, placement: 'after' };
        const header = [...this.rowsEl.querySelectorAll('.cueflow-group-row')].find(el => el.dataset.groupId === target.group.id);
        header?.classList.add('cueflow-group-drop-target');
      } else if (target.lane.id !== lane.id) {
        const placement = y < target.y + target.height / 2 ? 'before' : 'after';
        destination = { groupId: target.lane.groupId, anchorId: target.lane.id, placement };
        indicator.style.top = (target.y + (placement === 'after' ? target.height : 0)) + 'px'; indicator.hidden = false;
      }
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', preview); window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', cancel); window.removeEventListener('keydown', key);
      row?.classList.remove('cueflow-lane-reordering'); clearGroupHighlight(); ghost?.remove(); indicator.remove();
      this.pointerCleanup = null;
    };
    const cancel = () => cleanup();
    const key = e => { if (e.key === 'Escape') { e.preventDefault(); cancel(); } };
    const end = () => {
      const target = destination; cleanup();
      if (active && target && this.project === project) this.moveLaneTo(lane.id, target.groupId, target.anchorId, target.placement);
    };
    this.pointerCleanup = cancel;
    window.addEventListener('pointermove', preview); window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', cancel); window.addEventListener('keydown', key);
  }
  openDurationSettings() { new ProjectDurationModal(this).open(); }
  setProjectDuration(seconds) { return this.updateProjectSettings({ name: this.project.name, durationSec: seconds }); }
  updateProjectSettings({ name, durationSec: seconds }) {
    const title = String(name ?? '').trim();
    if (!title) { new Notice('项目名称不能为空'); return false; }
    if (!isInteger(seconds) || seconds < 60 || seconds > 86400) {
      new Notice('总时长请设置为 1 分钟到 24 小时之间'); return false;
    }
    if (seconds < latestCueEnd(this.project)) {
      new Notice('总时长不能早于最后一个动作的结束时间 T+' + fmtTime(latestCueEnd(this.project))); return false;
    }
    if (this.project.durationSec === seconds && this.project.name === title) return true;
    this.project.name = title; this.project.durationSec = seconds;
    if (this.elapsed > seconds) { this.pauseClock(); this.elapsed = seconds; }
    this.recordChange(); return true;
  }
  calculateDuration() {
    return Math.max(this.project.durationSec, latestCueEnd(this.project), 60);
  }
  pauseClock() {
    if (!this.running) return;
    this.elapsed = Math.min(this.calculateDuration(), this.timerBase + (performance.now() - this.timerOrigin) / 1000);
    this.running = false;
    if (this.tickHandle) window.clearInterval(this.tickHandle);
    this.tickHandle = null; this.updateClockUI();
  }
  toggleClock() {
    if (this.running) { this.pauseClock(); return; }
    this.running = true; this.timerBase = this.elapsed; this.timerOrigin = performance.now();
    this.tickHandle = window.setInterval(() => {
      this.elapsed = this.timerBase + (performance.now() - this.timerOrigin) / 1000;
      if (this.elapsed >= this.calculateDuration()) { this.elapsed = this.calculateDuration(); this.pauseClock(); }
      this.updateClockUI();
    }, 100);
    this.updateClockUI();
  }
  updateClockUI() {
    if (this.clockText) this.clockText.setText(`T+${fmtTime(this.elapsed)}`);
    if (this.playBtn) this.playBtn.setText(this.running ? 'Ⅱ 暂停' : '▶ 排练');
    if (this.playhead) this.playhead.style.left = `${this.labelWidth + this.elapsed * this.scale}px`;
    if (this.rulerPlayhead) this.rulerPlayhead.style.left = `${this.elapsed * this.scale}px`;
    if (this.board) {
      this.board.querySelectorAll('.cueflow-cue').forEach(el => {
        const cue = this.project.cues.find(c => c.id === el.dataset.id);
        el.classList.toggle('cueflow-now', !!cue && this.running && cue.durationSec > 0 && this.elapsed >= cue.startSec && this.elapsed < cue.startSec + cue.durationSec);
      });
    }
  }
  resetClock() { this.pauseClock(); this.elapsed = 0; this.updateClockUI(); }
  getProjectFolder() {
    return this.file?.path.includes('/') ? this.file.path.slice(0, this.file.path.lastIndexOf('/')) : this.plugin.settings.folder;
  }
  async exportCSV() {
    try {
      const csv = [['分组', '角色/设备', '动作', '开始(秒)', '结束(秒)', '持续(秒)', '状态', '前置动作', '备注']];
      const byId = new Map(this.project.cues.map(c => [c.id, c.name]));
      const laneMap = new Map(this.project.lanes.map(l => [l.id, l]));
      for (const c of [...this.project.cues].sort((a, b) => a.startSec - b.startSec)) csv.push([laneGroupName(this.project, laneMap.get(c.laneId)), laneMap.get(c.laneId)?.name, c.name, c.startSec, c.startSec + c.durationSec, c.durationSec, c.status, c.dependsOn.map(id => byId.get(id) || id).join('; '), c.note]);
      const escape = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
      const content = '\ufeff' + csv.map(row => row.map(escape).join(',')).join('\r\n');
      const base = `${this.getProjectFolder()}/${filenameFor(this.project.name)}-调度表`;
      let path = `${base}.csv`, i = 2;
      while (this.app.vault.getAbstractFileByPath(path)) path = `${base}-${i++}.csv`;
      await this.app.vault.create(path, content); new Notice(`已导出 ${path}`);
    } catch (err) { new Notice(`导出失败：${err.message}`); }
  }
  async exportSVG() {
    try {
      const scale = Math.max(1.4, Math.min(6, this.scale)), startX = 190, topY = 120, rowH = 72;
      const duration = this.calculateDuration();
      const layout = buildLaneLayout(this.project, new Set(), rowH);
      const w = Math.ceil(startX + duration * scale + 65), h = topY + layout.height + 38;
      const fragments = [`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">`,
        `<rect width="100%" height="100%" fill="#fff"/>`,
        `<text x="24" y="38" font-family="sans-serif" font-size="24" font-weight="bold" fill="#1c2734">${xmlEscape(this.project.name)}</text>`,
        `<text x="24" y="62" font-family="sans-serif" font-size="13" fill="#697688">CueFlow · 相对时间调度 · T+00:00</text>`];
      const timeStep = [5, 10, 15, 30, 60, 120, 300, 600].find(t => t * scale >= 65) || 600;
      for (let sec=0;sec<=duration;sec+=timeStep) {
        const x = startX + sec * scale;
        fragments.push(`<line x1="${x}" y1="${topY-18}" x2="${x}" y2="${h-30}" stroke="#e6ebf1"/>`,
          `<text x="${x+5}" y="${topY-25}" font-size="12" font-family="sans-serif" fill="#607083">${fmtTime(sec)}</text>`);
      }
      const laneMap = new Map(this.project.lanes.map(lane => [lane.id, lane]));
      for (const row of layout.rows) {
        const y = topY + row.y;
        if (row.kind === 'group') {
          fragments.push(`<rect x="0" y="${y}" width="${w}" height="${row.height}" fill="#e8edf5"/>`,
            `<text x="22" y="${y+24}" font-size="14" font-weight="bold" font-family="sans-serif" fill="#334155">${xmlEscape(row.group.name)} · ${row.lanes.length}</text>`);
          continue;
        }
        const lane = row.lane;
        fragments.push(`<rect x="0" y="${y}" width="${w}" height="${rowH}" fill="#ffffff"/>`,
          `<line x1="0" y1="${y+rowH}" x2="${w}" y2="${y+rowH}" stroke="#e4e9ef"/>`,
          `<rect x="21" y="${y+19}" width="6" height="30" rx="3" fill="${lane.color}"/>`,
          `<text x="39" y="${y+39}" font-size="14" font-family="sans-serif" fill="#1f2937">${xmlEscape(lane.name)}</text>`);
      }
      for (let sec=0;sec<=duration;sec+=timeStep) {
        const x = startX+sec*scale;
        fragments.push(`<line x1="${x}" y1="${topY}" x2="${x}" y2="${topY+layout.height}" stroke="#e6ebf1"/>`);
      }
      const byId = new Map(this.project.cues.map(c => [c.id,c]));
      for (const c of this.project.cues) {
        const y = topY+layout.laneY.get(c.laneId)+23, x=startX+c.startSec*scale;
        const lane = laneMap.get(c.laneId);
        fragments.push('<g><title>' + xmlEscape(c.name + ' · T+' + fmtTime(c.startSec) + ' · ' + c.note) + '</title>');
        if (!c.durationSec) {
          fragments.push(`<polygon points="${x},${y+2} ${x+10},${y+14} ${x},${y+26} ${x-10},${y+14}" fill="${lane.color}"/>`,
            `<text x="${x+15}" y="${y+18}" font-size="12" font-family="sans-serif" fill="#283442">${xmlEscape(c.name)}</text>`);
        } else {
          const bw=Math.max(16,c.durationSec*scale);
          fragments.push(`<rect x="${x}" y="${y}" width="${bw}" height="30" rx="5" fill="${lane.color}" opacity=".86"/>`,
            `<text x="${x+6}" y="${y+19}" font-size="12" font-family="sans-serif" fill="#fff">${xmlEscape(c.name.length > Math.max(4,Math.floor(bw/13)) ? c.name.slice(0,Math.max(3,Math.floor(bw/13))-1)+'…' : c.name)}</text>`);
        }
        fragments.push('</g>');
      }
      for (const c of this.project.cues) for (const id of c.dependsOn) {
        const from = byId.get(id); if(!from) continue;
        const x1=startX+(from.startSec+from.durationSec)*scale, x2=startX+c.startSec*scale;
        const y1=topY+layout.laneY.get(from.laneId)+38, y2=topY+layout.laneY.get(c.laneId)+38;
        const mid=x1+15;
        fragments.push(`<path d="M ${x1} ${y1} H ${mid} V ${y2} H ${x2}" fill="none" stroke="#465366" stroke-width="1.5" stroke-dasharray="3,3"/>`);
      }
      fragments.push('</svg>');
      const base = `${this.getProjectFolder()}/${filenameFor(this.project.name)}-甘特图`;
      let path = `${base}.svg`, n=2;
      while (this.app.vault.getAbstractFileByPath(path)) path=`${base}-${n++}.svg`;
      await this.app.vault.create(path, fragments.join('\n'));
      new Notice(`已导出 ${path}，可作为矢量图插入演示文稿`);
    } catch (err) { new Notice(`SVG 导出失败：${err.message}`); }
  }
  render(preserveScroll = false) {
    if (!this.project) return;
    this.inlineEdit?.finish(true, true);
    const prev = this.scroller, x = preserveScroll ? prev?.scrollLeft || 0 : 0, y = preserveScroll ? prev?.scrollTop || 0 : 0;
    const focused = document.activeElement === this.scroller;
    const root = this.contentEl; root.empty(); root.addClass('cueflow-root');
    const compact = this.density === 'compact';
    root.classList.toggle('cueflow-compact', compact);
    this.rowHeight = compact ? 40 : ROW_HEIGHT; this.groupHeight = compact ? 28 : GROUP_HEIGHT;
    this.scale = clamp(this.scale, ZOOMS[0]/60, ZOOMS[ZOOMS.length - 1]/60);
    const top = root.createDiv({ cls: 'cueflow-toolbar' });
    const brand = top.createDiv({ cls: 'cueflow-brand' }); brand.createSpan({ text: '◈', cls: 'cueflow-brand-symbol' }); brand.createSpan({ text: 'CueFlow' });
    select(top, this.files.map(f => [f.path, f.basename]), this.file?.path, async path => {
      const file = this.files.find(f => f.path === path); if (file) await this.openFile(file);
    }, '切换项目');
    btn(top, '+ 项目', () => new StringModal(this.app, '新建脚本项目', '项目名称', '新演示脚本', n => this.createProject(n)).open());
    btn(top, '项目设置', () => new ProjectDurationModal(this, true).open());
    btn(top, '显示设置', () => new DisplaySettingsModal(this).open());
    btn(top, '+ 分组', () => this.addGroup());
    btn(top, '+ 泳道', () => this.addLane());
    btn(top, '+ 动作', () => {
      const lane = buildLaneLayout(this.project).rows.find(r => r.kind === 'lane')?.lane;
      if (lane) this.addCue(lane.id, 0, 60); else new Notice('请先新建泳道');
    }, 'cueflow-primary');
    const second = root.createDiv({ cls: 'cueflow-subbar' });
    btn(second, '总时长 ' + fmtTime(this.calculateDuration()), () => this.openDurationSettings(), 'cueflow-small cueflow-duration');
    second.createSpan({ text: this.project.name, cls: 'cueflow-project-title' });
    second.createSpan({ text: `${this.project.groups.length} 个分组 · ${this.project.lanes.length} 条泳道 · ${this.project.cues.length} 个动作`, cls: 'cueflow-muted' });
    second.createSpan({ cls: 'cueflow-space' });
    second.createSpan({ text: '吸附', cls: 'cueflow-muted' });
    select(second, STEPS.map(s => [s, `${s}秒`]), this.snap, val => { this.snap = Number(val); this.plugin.settings.snapSeconds = this.snap; void this.plugin.saveSettings(); }, '拖拽吸附步长');
    btn(second, '−', () => this.setZoom(-1), 'cueflow-small');
    second.createSpan({ text: `${Math.round(this.scale * 60)}px/分`, cls: 'cueflow-zoom-text' });
    btn(second, '+', () => this.setZoom(1), 'cueflow-small');
    btn(second, '适应窗口', () => this.fitTimeline(), 'cueflow-small');
    btn(second, compact ? '紧凑显示 ✓' : '紧凑显示', () => this.setDensity(compact ? 'standard' : 'compact'), 'cueflow-small');
    btn(second, '撤销', () => this.undo(), 'cueflow-small');
    btn(second, '重做', () => this.redo(), 'cueflow-small');
    btn(second, this.autoSchedule ? '依赖顺延 ✓' : '手动排期', () => { this.autoSchedule = !this.autoSchedule; this.plugin.settings.autoSchedule = this.autoSchedule; void this.plugin.saveSettings(); this.render(true); }, 'cueflow-small');
    btn(second, '导出 CSV', () => this.exportCSV(), 'cueflow-small');
    btn(second, '导出 SVG', () => this.exportSVG(), 'cueflow-small');
    const clock = root.createDiv({ cls: 'cueflow-clockbar' });
    this.clockText = clock.createEl('strong', { text: `T+${fmtTime(this.elapsed)}`, cls: 'cueflow-clock' });
    this.playBtn = btn(clock, this.running ? 'Ⅱ 暂停' : '▶ 排练', () => this.toggleClock(), 'cueflow-primary');
    btn(clock, '↺ 归零', () => this.resetClock());
    clock.createSpan({ text: this.pendingLinkId ? '连接模式：点击后续动作建立依赖，按 Esc 取消' : '单击选中 · 双击动作编辑详情 · 双击空白新建并输入 · 按住拖动 · Delete 删除', cls: 'cueflow-help' });
    const scroll = root.createDiv({ cls: 'cueflow-scroller', attr: { tabindex: '0', 'aria-label': 'CueFlow 调度时间轴' } });
    this.scroller = scroll;
    this.duration = this.calculateDuration();
    const width = Math.ceil(this.duration * this.scale); this.timelineWidth = width;
    const board = scroll.createDiv({ cls: 'cueflow-board' }); this.board = board;
    board.style.width = `${this.labelWidth + width}px`;
    const topRow = board.createDiv({ cls: 'cueflow-heading' }); topRow.style.height = `${HEADER_HEIGHT}px`;
    const first = topRow.createDiv({ cls: 'cueflow-heading-left', text: '执行人员 / 设备' }); first.style.width = `${this.labelWidth}px`;
    const resizer = first.createDiv({ cls: 'cueflow-column-resizer', attr: {
      role: 'separator', tabindex: '0', 'aria-orientation': 'vertical', 'aria-label': '调整执行人员和设备列宽',
      'aria-valuemin': '160', 'aria-valuemax': '600', 'aria-valuenow': String(this.labelWidth), title: '左右拖动调整列宽；双击恢复默认' } });
    resizer.addEventListener('pointerdown', e => this.beginColumnResize(e));
    resizer.addEventListener('dblclick', e => { e.preventDefault(); this.setLabelWidth(LABEL_WIDTH); });
    resizer.addEventListener('keydown', e => {
      let value;
      if (e.key === 'ArrowLeft') value = this.labelWidth - (e.shiftKey ? 50 : 10);
      if (e.key === 'ArrowRight') value = this.labelWidth + (e.shiftKey ? 50 : 10);
      if (e.key === 'Home') value = 160;
      if (e.key === 'End') value = 600;
      if (value !== undefined) { e.preventDefault(); this.setLabelWidth(value); }
    });
    const ruler = topRow.createDiv({ cls: 'cueflow-ruler' }); ruler.style.width = `${width}px`;
    const candidates = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
    const tickStep = candidates.find(n => n * this.scale >= 67) || 3600;
    for (let sec = 0; sec <= this.duration; sec += tickStep) {
      const tick = ruler.createDiv({ cls: 'cueflow-tick', text: `T+${fmtTime(sec)}` }); tick.style.left = `${sec * this.scale}px`;
    }
    this.rulerPlayhead = ruler.createDiv({ cls: 'cueflow-ruler-now' });
    const rows = board.createDiv({ cls: 'cueflow-rows' }); this.rowsEl = rows;
    const layout = buildLaneLayout(this.project, this.collapsedGroups, this.rowHeight, this.groupHeight); this.laneLayout = layout;
    rows.style.minHeight = layout.height + 'px';
    for (const item of layout.rows) {
      if (item.kind === 'group') {
        const group = item.group;
        const row = rows.createDiv({ cls: 'cueflow-group-row' }); row.style.height = this.groupHeight + 'px';
        row.dataset.groupId = group.id;
        const label = row.createDiv({ cls: 'cueflow-group-label' }); label.style.width = this.labelWidth + 'px';
        if (group.id) {
          const handle = label.createSpan({ cls: 'cueflow-group-drag-handle', text: '⠿',
            attr: { role: 'button', tabindex: '0', title: '拖动整个分组及其全部泳道和动作', 'aria-label': '拖动分组 ' + group.name } });
          handle.addEventListener('pointerdown', e => this.beginGroupDrag(e, group));
          handle.addEventListener('keydown', e => {
            if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); this.moveGroup(group.id, e.key === 'ArrowUp' ? -1 : 1); }
          });
        }
        const toggle = btn(label, (this.collapsedGroups.has(group.id) ? '▸ ' : '▾ ') + group.name, () => this.toggleGroup(group.id), 'cueflow-group-toggle');
        toggle.setAttribute('aria-expanded', String(!this.collapsedGroups.has(group.id)));
        toggle.setAttribute('title', group.name + ' · ' + item.lanes.length + ' 条泳道');
        label.createSpan({ text: String(item.lanes.length), cls: 'cueflow-group-count' });
        const add = btn(label, '+', () => this.addLane(group.id), 'cueflow-iconbtn'); add.setAttribute('title', '在此分组新建泳道');
        if (group.id) {
          const options = btn(label, '⋯', e => this.openGroupMenu(group, e), 'cueflow-iconbtn'); options.setAttribute('title', '分组选项');
        }
        const band = row.createDiv({ cls: 'cueflow-group-band' }); band.style.width = width + 'px';
        continue;
      }
      const lane = item.lane;
      const row = rows.createDiv({ cls: 'cueflow-lane-row' }); row.style.height = `${this.rowHeight}px`; row.dataset.laneId = lane.id;
      const label = row.createDiv({ cls: 'cueflow-lane-label' }); label.style.width = `${this.labelWidth}px`;
      const handle = label.createSpan({ cls: 'cueflow-lane-drag-handle', text: '⠿',
        attr: { role: 'button', tabindex: '0', title: '拖动泳道上下排序或跨组移动；拖到分组标题可移入组末', 'aria-label': '拖动泳道 ' + lane.name } });
      handle.addEventListener('pointerdown', e => this.beginLaneDrag(e, lane));
      handle.addEventListener('keydown', e => {
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); this.moveLane(lane.id, e.key === 'ArrowUp' ? -1 : 1); }
      });
      const color = label.createSpan({ cls: 'cueflow-lane-color' }); color.style.backgroundColor = lane.color;
      const name = label.createSpan({ text: lane.name, cls: 'cueflow-lane-name' }); name.setAttribute('title', '双击编辑名称和分组：' + lane.name);
      name.addEventListener('dblclick', () => this.renameLane(lane));
      const options = label.createSpan({ cls: 'cueflow-lane-buttons' });
      btn(options, '+', () => this.addCue(lane.id, this.elapsed, 60), 'cueflow-iconbtn');
      const settingsButton = btn(options, '⋯', e => this.openLaneMenu(lane, e), 'cueflow-iconbtn');
      settingsButton.setAttribute('title', '泳道选项');
      const track = row.createDiv({ cls: 'cueflow-track' }); track.style.width = `${width}px`;
      track.style.setProperty('--cueflow-grid', `${tickStep * this.scale}px`);
      track.addEventListener('dblclick', e => {
        if (e.button !== 0 || e.target !== track) return;
        e.preventDefault(); e.stopPropagation();
        this.createCueAt(lane.id, (e.clientX - track.getBoundingClientRect().left) / this.scale);
      });
      for (const cue of this.project.cues.filter(c => c.laneId === lane.id).sort((a, b) => a.startSec - b.startSec)) this.renderCue(track, cue, lane);
    }
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg'); svg.classList.add('cueflow-links');
    svg.style.cssText = `left:${this.labelWidth}px;top:0px;width:${width}px;height:${layout.height}px`;
    svg.setAttribute('viewBox', `0 0 ${width} ${Math.max(1, layout.height)}`);
    svg.setAttribute('aria-hidden', 'true'); rows.appendChild(svg);
    this.drawLinks(svg);
    this.playhead = board.createDiv({ cls: 'cueflow-playhead' });
    this.playhead.style.height = `${HEADER_HEIGHT + layout.height}px`;
    this.footerEl = root.createDiv({ cls: 'cueflow-footer' }); this.renderFooter();
    scroll.scrollLeft = x; scroll.scrollTop = y;
    if (focused) scroll.focus({ preventScroll: true });
    scroll.addEventListener('keydown', e => this.handleCanvasKeydown(e));
    scroll.addEventListener('wheel', e => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault(); this.setZoom(e.deltaY < 0 ? 1 : -1);
    }, { passive: false });
    this.updateClockUI();
  }
  renderFooter() {
    const footer = this.footerEl; if (!footer) return; footer.empty();
    const current = this.project.cues.find(c => c.id === this.selectedId);
    if (current) {
      footer.createEl('strong', { text: current.name });
      footer.createSpan({ text: `T+${fmtTime(current.startSec)} – ${fmtTime(current.startSec + current.durationSec)} · ${fmtTime(current.durationSec)} · ${this.project.lanes.find(l => l.id === current.laneId)?.name || ''}` });
      btn(footer, '编辑详情', () => new CueModal(this, current).open());
      btn(footer, '删除', () => this.deleteCue(current.id));
    } else footer.createSpan({ text: '提示：选中任务查看详情；Ctrl+Z 撤销，Ctrl+Shift+Z 重做；任务重叠会显示红色虚线边框。' });
    this.saveStatusEl = footer.createSpan({ cls: 'cueflow-save-status' });
    this.recoveryActions = footer.createSpan({ cls: 'cueflow-recovery-actions' });
    btn(this.recoveryActions, '重试保存', () => this.saveNow(), 'cueflow-small');
    btn(this.recoveryActions, '保存为副本', () => this.saveRecoveryCopy(), 'cueflow-small');
    btn(this.recoveryActions, '重新读取', () => {
      if (window.confirm('重新读取会放弃当前未保存的修改。需要保留时，请先保存为副本。')) this.openFile(this.file, true);
    }, 'cueflow-small');
    this.updateSaveStatus();
  }
  selectCue(id) {
    this.selectedId = id;
    this.board.querySelectorAll('.cueflow-cue').forEach(el => el.classList.toggle('cueflow-selected', el.dataset.id === id));
    this.renderFooter();
  }
  setLabelWidth(value, persist = true) {
    const requested = Number(value);
    this.railWidth = Math.round(clamp(Number.isFinite(requested) ? requested : LABEL_WIDTH, 160, 600));
    if (this.board) {
      this.board.style.width = (this.labelWidth + this.timelineWidth) + 'px';
      this.board.querySelectorAll('.cueflow-heading-left,.cueflow-group-label,.cueflow-lane-label').forEach(el => el.style.width = this.labelWidth + 'px');
      const links = this.rowsEl.querySelector('.cueflow-links'); if (links) links.style.left = this.labelWidth + 'px';
      this.board.querySelector('.cueflow-column-resizer')?.setAttribute('aria-valuenow', String(this.labelWidth));
      this.updateClockUI();
    }
    if (persist) {
      this.plugin.settings.labelWidth = this.labelWidth;
      for (const leaf of this.app.workspace?.getLeavesOfType(VIEW_TYPE) || []) if (leaf.view !== this && leaf.view.plugin === this.plugin) leaf.view.setLabelWidth(this.labelWidth, false);
      void this.plugin.saveSettings();
    }
  }
  beginColumnResize(event) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation(); this.pointerCleanup?.();
    const initial = this.labelWidth, x = event.clientX;
    this.contentEl.classList.add('cueflow-column-resizing');
    const move = e => this.setLabelWidth(initial + e.clientX - x, false);
    const cleanup = () => {
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', cancel); window.removeEventListener('keydown', key);
      this.contentEl.classList.remove('cueflow-column-resizing'); this.pointerCleanup = null;
    };
    const end = () => { cleanup(); this.setLabelWidth(this.labelWidth); };
    const cancel = () => { cleanup(); this.setLabelWidth(initial, false); };
    const key = e => { if (e.key === 'Escape') { e.preventDefault(); cancel(); } };
    this.pointerCleanup = cancel;
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', cancel); window.addEventListener('keydown', key);
  }
  setPixelsPerMinute(value, persist = true) {
    const ppm = clamp(Number(value) || 180, 1, 900), old = this.scale;
    if (!this.scroller || !this.project) { this.scale = ppm / 60; return; }
    const center = (this.scroller.scrollLeft + this.scroller.clientWidth / 2 - this.labelWidth) / old;
    this.scale = ppm / 60; this.render(true);
    this.scroller.scrollLeft = Math.max(0, center * this.scale + this.labelWidth - this.scroller.clientWidth / 2);
    if (persist) { this.plugin.settings.pixelsPerMinute = ppm; void this.plugin.saveSettings(); }
  }
  fitTimeline() {
    const available = Math.max(1, this.scroller.clientWidth - this.labelWidth - 100);
    this.setPixelsPerMinute(Math.max(1, available * 60 / this.calculateDuration()));
    this.scroller.scrollLeft = 0;
  }
  setDensity(value, persist = true) {
    this.density = value === 'compact' ? 'compact' : 'standard'; this.render(true);
    if (persist) { this.plugin.settings.laneDensity = this.density; void this.plugin.saveSettings(); }
  }
  setZoom(direction) {
    const current = this.scale * 60;
    let index = ZOOMS.reduce((best, val, i) => Math.abs(val-current) < Math.abs(ZOOMS[best]-current) ? i : best, 0);
    index = clamp(index + direction, 0, ZOOMS.length - 1);
    this.setPixelsPerMinute(ZOOMS[index]);
  }
  openLaneMenu(lane, e) {
    const menu = new Menu();
    menu.addItem(i => i.setTitle('编辑名称 / 分组 / 颜色').setIcon('pencil').onClick(() => this.renameLane(lane)));
    menu.addItem(i => i.setTitle('在组内上移').setIcon('arrow-up').onClick(() => this.moveLane(lane.id, -1)));
    menu.addItem(i => i.setTitle('在组内下移').setIcon('arrow-down').onClick(() => this.moveLane(lane.id, 1)));
    menu.addSeparator(); menu.addItem(i => i.setTitle('删除空泳道').setIcon('trash').onClick(() => this.removeLane(lane)));
    menu.showAtMouseEvent(e);
  }
  openGroupMenu(group, e) {
    const menu = new Menu();
    menu.addItem(i => i.setTitle('修改分组名称').setIcon('pencil').onClick(() => this.renameGroup(group)));
    menu.addItem(i => i.setTitle('新增泳道').setIcon('plus').onClick(() => this.addLane(group.id)));
    menu.addItem(i => i.setTitle('上移分组').setIcon('arrow-up').onClick(() => this.moveGroup(group.id, -1)));
    menu.addItem(i => i.setTitle('下移分组').setIcon('arrow-down').onClick(() => this.moveGroup(group.id, 1)));
    menu.addSeparator();
    menu.addItem(i => i.setTitle('删除分组（保留泳道）').setIcon('trash').onClick(() => this.removeGroup(group)));
    menu.showAtMouseEvent(e);
  }
  renderCue(track, cue, lane) {
    const milestone = cue.durationSec === 0;
    const el = track.createDiv({ cls: `cueflow-cue ${milestone ? 'cueflow-milestone' : ''} ${cue.status === 'done' ? 'cueflow-done' : ''} ${hasConflict(this.project, cue) ? 'cueflow-conflict' : ''} ${this.selectedId === cue.id ? 'cueflow-selected' : ''}` });
    el.dataset.id = cue.id; el.style.left = `${cue.startSec * this.scale}px`;
    el.style.width = `${Math.max(milestone ? 18 : cue.durationSec * this.scale, milestone ? 18 : 20)}px`;
    el.style.setProperty('--cueflow-color', lane.color);
    el.setAttribute('title', `${cue.name}\nT+${fmtTime(cue.startSec)} 至 T+${fmtTime(cue.startSec + cue.durationSec)}\n${cue.note}`);
    if (!milestone) {
      const left = el.createDiv({ cls: 'cueflow-resize cueflow-resize-left' });
      left.addEventListener('pointerdown', e => this.beginMove(e, cue, el, 'resize-left'));
    }
    const text = el.createSpan({ text: milestone ? `◆ ${cue.name}` : cue.name, cls: 'cueflow-cue-title' });
    el.addEventListener('pointerdown', e => this.beginMove(e, cue, el, 'move'));
    if (!milestone) {
      const right = el.createDiv({ cls: 'cueflow-resize cueflow-resize-right' });
      right.addEventListener('pointerdown', e => this.beginMove(e, cue, el, 'resize-right'));
    }
    const link = el.createSpan({ text: '○', cls: 'cueflow-connect', attr: { title: '点击建立依赖，再点击后续动作' } });
    link.addEventListener('pointerdown', e => e.stopPropagation());
    link.addEventListener('click', e => { e.stopPropagation(); this.pendingLinkId = cue.id; new Notice('已选择前置动作，请点击另一个任务条以建立依赖'); this.render(true); });
    el.addEventListener('click', e => {
      e.stopPropagation();
      if (this.pendingLinkId && this.pendingLinkId !== cue.id) { this.addDependency(this.pendingLinkId, cue.id); return; }
      this.selectCue(cue.id);
    });
    el.addEventListener('dblclick', e => { e.preventDefault(); e.stopPropagation(); new CueModal(this, cue).open(); });
    el.addEventListener('contextmenu', e => {
      e.preventDefault(); e.stopPropagation(); const menu = new Menu();
      menu.addItem(i => i.setTitle('编辑动作').setIcon('pencil').onClick(() => new CueModal(this, cue).open()));
      menu.addItem(i => i.setTitle('复制动作').setIcon('copy').onClick(() => this.duplicateCue(cue)));
      menu.addItem(i => i.setTitle('设为里程碑').setIcon('flag').onClick(() => { cue.durationSec = 0; this.recordChange(); }));
      menu.addItem(i => i.setTitle('切换完成状态').setIcon('check').onClick(() => { cue.status = cue.status === 'done' ? 'planned' : 'done'; this.recordChange(); }));
      menu.addSeparator(); menu.addItem(i => i.setTitle('删除动作').setIcon('trash').onClick(() => this.deleteCue(cue.id)));
      menu.showAtMouseEvent(e);
    });
  }
  beginMove(e, cue, el, kind) {
    if (e.button !== 0) return;
    e.stopPropagation(); e.preventDefault();
    this.pointerCleanup?.();
    this.scroller.focus({ preventScroll: true }); this.selectCue(cue.id);
    const pointerX = e.clientX, pointerY = e.clientY;
    const oldStart = cue.startSec, oldDuration = cue.durationSec, oldLaneId = cue.laneId;
    const startRowY = this.laneLayout.laneY.get(cue.laneId), oldTitle = el.getAttribute('title');
    let lastStart = oldStart, lastDuration = oldDuration, lastLaneId = oldLaneId, moved = false;
    const move = event => {
      if (!moved && Math.hypot(event.clientX - pointerX, kind === 'move' ? event.clientY - pointerY : 0) < 4) return;
      moved = true; el.classList.add('cueflow-dragging');
      const deltaSec = (event.clientX - pointerX) / this.scale;
      if (kind === 'move') lastStart = clamp(roundSnap(oldStart + deltaSec, this.snap), 0, 86400-oldDuration);
      else if (kind === 'resize-right') lastDuration = clamp(Math.round((oldDuration+deltaSec) / this.snap)*this.snap, MIN_CUE_SEC, 86400-oldStart);
      else {
        const end = oldStart + oldDuration;
        lastStart = clamp(roundSnap(oldStart+deltaSec, this.snap), 0, end - MIN_CUE_SEC);
        lastDuration = end-lastStart;
      }
      if (kind === 'move') {
        const target = laneAtY(this.laneLayout, event.clientY - this.rowsEl.getBoundingClientRect().top);
        lastLaneId = target?.lane.id || oldLaneId;
        el.style.transform = 'translateY(' + (target ? target.y - startRowY : 0) + 'px)';
      }
      el.style.left = `${lastStart*this.scale}px`;
      el.style.width = `${Math.max(20, lastDuration*this.scale)}px`;
      el.setAttribute('title', `T+${fmtTime(lastStart)} / ${fmtTime(lastDuration)}`);
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', cancel); window.removeEventListener('keydown', key);
      this.pointerCleanup = null; el.classList.remove('cueflow-dragging');
    };
    const restore = () => {
      el.style.left = (oldStart * this.scale) + 'px'; el.style.width = Math.max(cue.durationSec ? 20 : 18, oldDuration * this.scale) + 'px';
      el.style.transform = ''; el.setAttribute('title', oldTitle);
    };
    const end = () => {
      cleanup();
      if (moved && (lastStart !== oldStart || lastDuration !== oldDuration || lastLaneId !== oldLaneId)) {
        if (!this.saveCue({ ...cue, startSec: lastStart, durationSec: lastDuration, laneId: lastLaneId })) this.render(true);
      } else { restore(); this.selectCue(cue.id); }
    };
    const cancel = () => { cleanup(); restore(); };
    const key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); cancel(); } };
    this.pointerCleanup = cancel;
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', cancel); window.addEventListener('keydown', key);
  }
  drawLinks(svg) {
    const ns = 'http://www.w3.org/2000/svg';
    const laneY = this.laneLayout.laneY;
    const byId = new Map(this.project.cues.map(c => [c.id, c]));
    const group = document.createElementNS(ns, 'g'); svg.appendChild(group);
    const defs = document.createElementNS(ns, 'defs');
    defs.innerHTML = '<marker id="cueflow-arrowhead" markerWidth="7" markerHeight="7" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="none" stroke="var(--text-muted)" stroke-width="1.2"/></marker>';
    svg.appendChild(defs);
    for (const cue of this.project.cues) for (const id of cue.dependsOn) {
      const pred = byId.get(id); if (!pred || !laneY.has(pred.laneId) || !laneY.has(cue.laneId)) continue;
      const a = (pred.startSec + pred.durationSec) * this.scale;
      const b = cue.startSec * this.scale;
      const y1 = laneY.get(pred.laneId)+this.rowHeight/2;
      const y2 = laneY.get(cue.laneId)+this.rowHeight/2;
      const x1 = a + 2, x2 = b - 2;
      const mid = x1 + Math.max(15, (x2-x1)/2);
      const d = `M${x1},${y1} L${mid},${y1} L${mid},${y2} L${x2},${y2}`;
      const path = document.createElementNS(ns, 'path');
      path.setAttribute('d', d); path.setAttribute('fill', 'none'); path.setAttribute('stroke', 'var(--text-muted)');
      path.setAttribute('stroke-opacity', '.58'); path.setAttribute('stroke-width', '1.4');
      path.setAttribute('marker-end', 'url(#cueflow-arrowhead)');
      if (x2 < x1) path.setAttribute('stroke-dasharray', '4 3');
      group.appendChild(path);
    }
  }
}

module.exports = class CueFlowPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULTS, await this.loadData());
    this.settings.labelWidth = Math.round(clamp(positive(this.settings.labelWidth, LABEL_WIDTH), 160, 600));
    this.registerView(VIEW_TYPE, leaf => new CueFlowView(leaf, this));
    this.addRibbonIcon('calendar-clock', '打开 CueFlow 时间轴', () => this.activate());
    this.addCommand({ id: 'open-timeline', name: '打开演示脚本时间轴', callback: () => this.activate() });
    this.addSettingTab(new CueFlowSettingTab(this.app, this));
  }
  async saveSettings() {
    const snapshot = deepCopy(this.settings);
    this.settingsSaveChain = (this.settingsSaveChain || Promise.resolve()).catch(() => {}).then(() => this.saveData(snapshot));
    return this.settingsSaveChain;
  }
  async activate() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) { leaf = this.app.workspace.getLeaf('tab'); await leaf.setViewState({ type: VIEW_TYPE, active: true }); }
    this.app.workspace.revealLeaf(leaf);
  }
  onunload() { this.app.workspace.detachLeavesOfType(VIEW_TYPE); }
};

// Export non-Obsidian pure helpers for local smoke tests (Obsidian ignores this).
module.exports.__test = { fmtTime, parseTime, validateProject, createsCycle, scheduleDependents, hasConflict, makeExample, roundSnap, CueFlowView, safeMarkdown, xmlEscape, laneGroupName, buildLaneLayout, laneAtY, LaneModal, StringModal, CueModal, CueFlowSettingTab, dependencyOrder, DisplaySettingsModal, normalizeFolder, latestCueEnd, ProjectDurationModal };
